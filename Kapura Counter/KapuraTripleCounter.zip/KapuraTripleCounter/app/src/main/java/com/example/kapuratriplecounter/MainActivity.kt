package com.example.kapuratriplecounter

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.Toast
import androidx.databinding.DataBindingUtil
import androidx.fragment.app.FragmentActivity
import com.example.kapuratriplecounter.databinding.ActivityMainBinding
import kotlin.math.max


class MainActivity : FragmentActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = DataBindingUtil.setContentView<ActivityMainBinding>(this, R.layout.activity_main)

        binding.addOne.setOnClickListener {
            addNumber(it)
        }
        binding.addTwo.setOnClickListener {
            addNumber(it)
        }
        binding.addThree.setOnClickListener {
            addNumber(it)
        }
        binding.revertOne.setOnClickListener {
            revertNumber(it)
        }
        binding.revertTwo.setOnClickListener {
            revertNumber(it)
        }
        binding.revertThree.setOnClickListener {
            revertNumber(it)
        }
        binding.resetButton.setOnClickListener{
            resetToStart(it)
        }
    }

    private fun addNumber(view: View) {
        var current: EditText? = null
        var goal: EditText? = null
        var increment: EditText? = null
        binding.apply {
            if (view == addOne) {
                current = currentOne
                goal = goalOne
                increment = incrementOne
            } else if (view == addTwo) {
                current = currentTwo
                goal = goalTwo
                increment = incrementTwo
            } else if (view == addThree) {
                current = currentThree
                goal = goalThree
                increment = incrementThree
            }
            if (increment?.text.isNullOrBlank()) { // if increment not given, show message
                Toast.makeText(this@MainActivity, "Required: Number to add by", Toast.LENGTH_SHORT)
                    .show()
            } else if (goal?.text.isNullOrBlank()) { // if goal not set, show message
                Toast.makeText(this@MainActivity, "Required: Goal Number", Toast.LENGTH_SHORT)
                    .show()
            } else if (current?.text.isNullOrBlank()) { // if no text in current
                current?.text = increment?.text
            } else {
                var oldNum = current?.getText().toString().toInt()
                var addBy = increment?.getText().toString().toInt()
                var newNum = oldNum + addBy
                current?.setText(newNum.toString())
                Toast.makeText(this@MainActivity, "Yay!", Toast.LENGTH_SHORT).show()
                goalCheck()
            }
        }
    }

    private fun goalCheck() {
        binding.apply {
            val checkList =
                listOf(currentOne, currentTwo, currentThree, goalOne, goalTwo, goalThree)
            var tick = true
            for (et in checkList) {
                if (et?.text.isNullOrBlank()) {
                    tick = false
                }
            }
            if (tick == true) {
                if (currentOne.text.toString().toInt() >= goalOne.text.toString().toInt() &&
                    currentTwo.text.toString().toInt() >= goalTwo.text.toString().toInt() &&
                    currentThree.text.toString().toInt() >= goalThree.text.toString().toInt()
                ) { // if daily goal is met
                    thanks.visibility = View.VISIBLE
                    resetButton.visibility = View.VISIBLE
                }
            }
        }
    }

    private fun revertNumber(view: View) {
        binding.apply {

            var current: EditText? = null
            var goal: EditText? = null
            var increment: EditText? = null

            if (view == revertOne) {
                current = currentOne
                goal = goalOne
                increment = incrementOne
            } else if (view == revertTwo) {
                current = currentTwo
                goal = goalTwo
                increment = incrementTwo
            } else if (view == revertThree) {
                current = currentThree
                goal = goalThree
                increment = incrementThree
            }
            if (increment?.text.isNullOrBlank()) { // if incrementBy not given, show message
                Toast.makeText(
                    this@MainActivity,
                    "Required: Number to subtract by",
                    Toast.LENGTH_SHORT
                ).show()
            } else if (goal?.text.isNullOrBlank()) { // if goal not set, show message
                Toast.makeText(
                    this@MainActivity,
                    "Required: Goal Number",
                    Toast.LENGTH_SHORT
                )
                    .show()
            } else if (current?.text.isNullOrBlank() || (current?.text.toString() == "0")) { // if no text in current or is zero
                Toast.makeText(
                    this@MainActivity,
                    "Cannot revert below 0",
                    Toast.LENGTH_SHORT
                )
                    .show()
            } else {
                var oldNum = current?.getText().toString().toInt()
                var subtractBy = increment?.getText().toString().toInt()
                var newNum = max(0, oldNum - subtractBy)
                current?.setText(newNum.toString())
            }


        }
    }

    private fun resetToStart(view: View) {
        binding.apply{
            val editList = listOf(currentOne, currentTwo, currentThree, goalOne, goalTwo, goalThree, incrementOne, incrementTwo, incrementThree)
            for (et in editList) {
                et.setText("")
            }
            resetButton.visibility = View.GONE
            thanks.visibility = View.GONE
        }
    }
}
//        // increment onClick function
//        binding.addButton.setOnClickListener{
//            addNumber(it)
//        }
//        binding.revertButton.setOnClickListener{
//            revertNumber(it)
//        }
//        binding.resetButton.setOnClickListener{
//            resetToStart(it)
//        }
//
//    }
//
//    private fun addNumber(view: View) {
//        binding.apply {
//            if (incrementBy.text.isNullOrBlank()) { // if incrementBy not given, show message
//                Toast.makeText(this@MainActivity, "Required: Number to add by", Toast.LENGTH_SHORT).show()
//            } else if (goalCount.text.isNullOrBlank()) { // if goal not set, show message
//                Toast.makeText(this@MainActivity, "Required: Goal Number", Toast.LENGTH_SHORT).show()
//            }
//            else if (currentCount.text.isNullOrBlank()) { // if no text in currentCount
//                currentCount.text = incrementBy.text
//            } else {
//                var oldNum = currentCount.getText().toString().toInt()
//                var addBy =  incrementBy.getText().toString().toInt()
//                var newNum = oldNum + addBy
//                currentCount.setText(newNum.toString())
//                Toast.makeText(this@MainActivity, "Yay!", Toast.LENGTH_SHORT).show()
//                goalCheck()
//            }
//
//        }
//    }
//
//    private fun revertNumber(view: View) {
//        binding.apply {
//            if (incrementBy.text.isNullOrBlank()) { // if incrementBy not given, show message
//                Toast.makeText(this@MainActivity, "Required: Number to subtract by", Toast.LENGTH_SHORT).show()
//            } else if (goalCount.text.isNullOrBlank()) { // if goal not set, show message
//                Toast.makeText(this@MainActivity, "Required: Goal Number", Toast.LENGTH_SHORT).show()
//            } else if (currentCount.text.isNullOrBlank() || (currentCount.text.toString() == "0")) { // if no text in currentCount or is zero
//                Toast.makeText(this@MainActivity, "Cannot revert below 0", Toast.LENGTH_SHORT).show()
//            } else {
//                var oldNum = currentCount.getText().toString().toInt()
//                var subtractBy = incrementBy.getText().toString().toInt()
//                var newNum = max(0, oldNum - subtractBy)
//                currentCount.setText(newNum.toString())
//            }
//        }
//    }
//
//    private fun goalCheck() {
//        binding.apply{
//            var current = currentCount.text.toString().toInt()
//            var goal = goalCount.text.toString().toInt()
//            if (current >= goal) { // if daily goal is met
//                goalReachedMessage.visibility = View.VISIBLE
//                resetButton.visibility = View.VISIBLE
//            }
//        }
//    }
//
//    private fun resetToStart(view: View) {
//        binding.apply{
//            currentCount.setText("")
//            goalCount.setText("")
//            incrementBy.setText("")
//            resetButton.visibility = View.GONE
//            goalReachedMessage.visibility = View.GONE
//
//        }
//    }
//}